const mongoose = require('mongoose');

const administradorSchema = new mongoose.Schema({
  customId: { type: Number, unique: true, required: true },
  nome: { type: String, required: true, unique: true /* ← Isso garante que o nome seja único no banco */ },
  senha: { type: String, required: true },
  celular: { 
    type: Number, required: true }
}, { timestamps: true });

module.exports = mongoose.model('Administrador', administradorSchema);