const mongoose = require('mongoose');

const desaparecidoSchema = new mongoose.Schema({
  customId: { type: Number, unique: true, required: true },

  nomeContato: { type: String },
  cpfContato: { type: String },  // CPF armazenado como string
  email: { type: String },
  telefoneContato: { type: String },  // Telefone como string para preservar zeros e símbolos

  cidade: { type: String },
  nomeDesaparecido: { type: String },
  dataNascimento: { type: Date },
  nomeMae: { type: String },
  dataDesaparecimento: { type: Date },
  localDesaparecimento: { type: String },
  numeroBo: { type: String },  // Número BO como string (pode ter letras/tracos)

  informacoesContato: { type: String },
  outrasInformacoes: { type: String, required: true },
  foto: { type: String },

  denunciaAnonima: { type: Boolean, default: false },

  criadoPor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Usuario',
    required: true
  }
}, { timestamps: true });

module.exports = mongoose.model('Desaparecido', desaparecidoSchema);
