const mongoose = require('mongoose');

const usuarioSchema = new mongoose.Schema({
  customId: { type: Number, unique: true, required: true },
  nome: { type: String, required: true, unique: true /* ← Isso garante que o nome seja único no banco */ },
  cpf: { type: Number, required: true }
}, { timestamps: true });

module.exports = mongoose.model('Usuario', usuarioSchema);