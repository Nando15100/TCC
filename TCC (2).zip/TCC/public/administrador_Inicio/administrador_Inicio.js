fetch('/verificar_sessao_admin')
      .then(res => res.json())
      .then(data => {
        if (!data.logado) {
          alert('Você precisa estar logado como administrador!');
          window.location.href = '../administrador_Login/administrador_Login.html';
        } else {
          document.getElementById('admin-nome').textContent = `Bem-vindo(a), ${data.nome}`;
        }
      });

// Função de logout com confirmação
function logout() {
    const confirmar = confirm('Deseja realmente sair?');
    if (confirmar) {
        fetch('/logout_admin', { method: 'POST' })
          .then(() => {
            window.location.href = '../administrador_login/administrador_login.html';
          });
    }
}