const botao_Login = document.getElementById('form-login');

botao_Login.addEventListener('submit', async function (evento) {
  evento.preventDefault();

  const nome = document.getElementById('usuario').value.trim();
  const cpf = document.getElementById('cpf').value;

  try {
    const resposta = await fetch('/usuario_login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nome, cpf })
    });

    const json = await resposta.json();

    if (resposta.ok) {
      window.location.href = '/cadastro_Desaparecidos_Inicio/cadastro_Desaparecidos_Inicio.html';
    } else {
      alert(json.mensagem || 'Erro no login');
    }
  } catch (erro) {
    console.error('Erro:', erro);
    alert('Erro ao logar');
  }
});
