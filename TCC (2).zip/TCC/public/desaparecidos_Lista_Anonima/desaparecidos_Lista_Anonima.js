// Carrega apenas desaparecidos com denúncia anônima
async function carregarDesaparecidosAnonimos() {
  try {
    const resposta = await fetch('/listar_desaparecidos_anonimos');
    const dados = await resposta.json();

    const corpo = document.getElementById('corpo-tabela');
    corpo.innerHTML = '';

    if (dados.length === 0) {
      corpo.innerHTML = '<tr><td colspan="3">Nenhuma denúncia anônima encontrada.</td></tr>';
      return;
    }

    dados.forEach(pessoa => {
      const tr = document.createElement('tr');

      // Para evitar problemas com apóstrofos e caracteres especiais,
      // passamos dados via data-attributes e manipulamos depois.
      tr.innerHTML = `
        <td>${pessoa.customId}</td>
        <td>${pessoa.cidade || 'Não informada'}</td>
        <td>
          <button 
            class="btn btn-warning btn-sm me-2 btn-editar" 
            data-id="${pessoa.customId}" 
            data-cidade="${encodeURIComponent(pessoa.cidade || '')}">
            ✏️
          </button>
          <button onclick="excluir(${pessoa.customId})" class="btn btn-danger btn-sm me-2">🗑️</button>
          <button onclick="visualizar(${pessoa.customId})" class="btn btn-info btn-sm">👁️</button>
        </td>
      `;
      corpo.appendChild(tr);
    });

    // Adiciona listener para botões editar
    document.querySelectorAll('.btn-editar').forEach(btn => {
      btn.addEventListener('click', () => {
        const customId = btn.getAttribute('data-id');
        const cidade = decodeURIComponent(btn.getAttribute('data-cidade'));
        editar(customId, cidade);
      });
    });

  } catch (erro) {
    console.error('Erro ao carregar dados:', erro);
  }
}

window.onload = carregarDesaparecidosAnonimos;

// Editar cidade
function editar(customId, cidadeAtual) {
  document.getElementById('edit-id').value = customId;
  document.getElementById('edit-cidade').value = cidadeAtual;

  const modal = new bootstrap.Modal(document.getElementById('modalEdicao'));
  modal.show();
}

// Submit do modal
document.getElementById('form-edicao').addEventListener('submit', async function (e) {
  e.preventDefault();

  const customId = document.getElementById('edit-id').value;
  const novaCidade = document.getElementById('edit-cidade').value.trim();

  try {
    // Corrigida URL para bater com backend
    const resposta = await fetch(`/editar_cidade/${customId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cidade: novaCidade })
    });

    if (resposta.ok) {
      alert('Cidade atualizada com sucesso!');
      bootstrap.Modal.getInstance(document.getElementById('modalEdicao')).hide();
      carregarDesaparecidosAnonimos();
    } else {
      alert('Erro ao atualizar cidade.');
    }
  } catch (erro) {
    console.error('Erro ao atualizar cidade:', erro);
  }
});

// Excluir desaparecido
async function excluir(customId) {
  if (!confirm('Tem certeza que deseja excluir este registro?')) return;

  try {
    const resposta = await fetch(`/excluir_desaparecido/${customId}`, {
      method: 'DELETE'
    });

    if (resposta.ok) {
      alert('Registro excluído com sucesso!');
      carregarDesaparecidosAnonimos();
    } else {
      alert('Erro ao excluir o registro.');
    }
  } catch (erro) {
    console.error('Erro ao excluir:', erro);
  }
}

// Redirecionar para página de visualização
function visualizar(customId) {
  window.location.href = `/desaparecidos_Visualizar_Anonima/desaparecidos_Visualizar_Anonima.html?id=${customId}`;
}


//Caixa de 
function pesquisando_Dados() {
    const filtro = document.getElementById('pesquisar').value.toLowerCase();
    const linhas = document.querySelectorAll('#corpo-tabela tr');

    // Remove a linha da mensagem, se estiver presente
    const linhaMensagem = document.getElementById('linha-vazia');
    if (linhaMensagem) linhaMensagem.remove();

    let encontrou = false;

    linhas.forEach(tr => {
        const id = tr.cells[0].textContent.toLowerCase();      // Coluna ID
        const nome = tr.cells[1].textContent.toLowerCase();    // Coluna Nome

                            /*Pesquisa por ID*/    /*PESQUISA POR NOME*/
        const corresponde = id.includes(filtro) || nome.includes(filtro);

        tr.style.display = corresponde ? '' : 'none';
        if (corresponde) encontrou = true;
    });

    if (!encontrou) {
        const tbody = document.getElementById('corpo-tabela');
        const tr = document.createElement('tr');
        tr.id = 'linha-vazia';
        tr.classList.add('mensagem-vazia');
        tr.innerHTML = `<td colspan="6">Nenhum registro encontrado.</td>`;
        tbody.appendChild(tr);
    }
}
document.getElementById('pesquisar')
    .addEventListener('keydown', e => {
        if (e.key === 'Enter') {
            e.preventDefault();
            pesquisando_Dados();
        }
    });
