 // Verifica sessão e exibe o nome
    fetch('/verificar_sessao_admin')
      .then(res => res.json())
      .then(data => {
        if (!data.logado) {
          alert('Você precisa estar logado como administrador!');
          window.location.href = '../administrador_Login/administrador_Login.html';
        } else {
          document.getElementById('admin-nome').textContent = `Bem-vindo(a), ${data.nome}`;
        }
      });

    // Logout com confirmação
    function logout() {
      if (confirm('Deseja realmente sair?')) {
        fetch('/logout_admin', { method: 'POST' })
          .then(() => window.location.href = '../administrador_Inicio/administrador_Inicio.html');
      }
    }

    // Confirmação padrão (não mais usada com botão novo, mas mantida se necessário)
    function confirmaSaida() {
      return confirm('Tem certeza que deseja sair?');
    }

    // Caixa de pesquisa
    function pesquisando_Dados() {
      const filtro = document.getElementById('pesquisar').value.toLowerCase();
      const linhas = document.querySelectorAll('#corpo-tabela tr');
      const linhaMensagem = document.getElementById('linha-vazia');
      if (linhaMensagem) linhaMensagem.remove();

      let encontrou = false;

      linhas.forEach(tr => {
        const nomeUsuario = tr.cells[1].textContent.toLowerCase();
        const cpf = tr.cells[2].textContent.toLowerCase();
        const corresponde = nomeUsuario.includes(filtro) || cpf.includes(filtro);
        tr.style.display = corresponde ? '' : 'none';
        if (corresponde) encontrou = true;
      });

      if (!encontrou) {
        const tbody = document.getElementById('corpo-tabela');
        const tr = document.createElement('tr');
        tr.id = 'linha-vazia';
        tr.classList.add('mensagem-vazia');
        tr.innerHTML = `<td colspan="6">Nenhum registro encontrado.</td>`;
        tbody.appendChild(tr);
      }
    }

    document.getElementById('pesquisar').addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        pesquisando_Dados();
      }
    });

    // Lista os dados
    async function carregarDados() {
      try {
        const resposta = await fetch('/registros_Usuario');
        const dados = await resposta.json();
        const corpo = document.getElementById('corpo-tabela');
        corpo.innerHTML = '';

        dados.forEach(item => {
          const tr = document.createElement('tr');
          const criadoEm = new Date(item.createdAt).toLocaleString('pt-BR');
          tr.innerHTML = `
            <td>${item.customId}</td>
            <td>${item.nome}</td>
            <td>${item.cpf}</td>
            <td>${criadoEm}</td>
            <td>
              <span class="icon" onclick="iniciarEdicao(this, ${item.customId})">✏️</span>
              <span class="icon" onclick="excluirRegistro(${item.customId})">🗑️</span>
            </td>
          `;
          corpo.appendChild(tr);
        });
      } catch (err) {
        console.error('Erro ao carregar dados:', err);
      }
    }

    function iniciarEdicao(el, id) {
      const tr = el.closest('tr');
      const cells = tr.querySelectorAll('td');
      ['nome', 'cpf'].forEach((field, idx) => {
        const td = cells[idx + 1];
        const valor = td.textContent;
        td.innerHTML = `<input class="edit-field" id="edit-${field}-${id}" value="${valor}">`;
      });
      el.textContent = '💾';
      el.onclick = () => salvarEdicao(id);
    }

    async function salvarEdicao(id) {
      const nome = document.getElementById(`edit-nome-${id}`).value.trim();
      const cpf = document.getElementById(`edit-cpf-${id}`).value.trim();

      const res = await fetch(`/atualizar_Usuario/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome, cpf })
      });

      if (res.ok) carregarDados();
      else alert('Erro ao salvar edição');
    }

    async function excluirRegistro(id) {
      if (!confirm('Deseja realmente excluir este registro?')) return;
      const res = await fetch(`/excluir_Usuario/${id}`, { method: 'DELETE' });
      if (res.ok) carregarDados();
      else alert('Erro ao excluir registro');
    }

    carregarDados();