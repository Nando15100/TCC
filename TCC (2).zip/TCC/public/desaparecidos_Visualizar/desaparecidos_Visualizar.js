document.addEventListener('DOMContentLoaded', async () => {
  validarSessao();

  const urlParams = new URLSearchParams(window.location.search);
  const customId = urlParams.get('id');

  if (!customId) {
    alert('ID inválido. Retornando à lista.');
    window.location.href = 'desaparecidos_Lista.html';
    return;
  }

  await carregarDados(customId);

  document.getElementById('btn-editar').addEventListener('click', async () => {
    const btn = document.getElementById('btn-editar');
    const modoEdicao = btn.dataset.modo === 'editar';

    if (modoEdicao) {
      habilitarCampos(true);
      btn.textContent = 'Salvar';
      btn.dataset.modo = 'salvar';
    } else {
      await salvarDados(customId);
      habilitarCampos(false);
      btn.textContent = 'Editar';
      btn.dataset.modo = 'editar';
    }
  });

  document.getElementById('btn-foto').addEventListener('click', () => {
    if (!document.getElementById('foto').disabled) {
      document.getElementById('foto').click();
    }
  });
});

// Apenas redireciona para a lista, sem destruir sessão
function sair() {
  
  window.location.href = 'http://localhost:3000/desaparecidos_Lista/desaparecidos_Lista.html';
}

function validarSessao() {
  fetch('/verificar_sessao_admin')
    .then(res => res.json())
    .then(data => {
      if (!data.logado) {
        alert('Você precisa estar logado como administrador!');
        window.location.href = '../administrador_Login/administrador_Login.html';
      } else {
        document.getElementById('admin-nome').textContent = `Bem-vindo(a),  ${data.nome}`;
      }
    })
    .catch(err => {
      console.error('Erro ao verificar sessão:', err);
      alert('Erro ao verificar sessão. Redirecionando...');
      window.location.href = '../administrador_Login/administrador_Login.html';
    });
}

function habilitarCampos(habilitar) {
  const ids = [
    'nomeContato', 'cpfContato', 'email', 'telefoneContato',
    'nomeDesaparecido', 'dataNascimento', 'nomeMae', 'dataDesaparecimento',
    'localDesaparecimento', 'numeroBo', 'outrasInformacoes', 'foto'
  ];

  ids.forEach(id => {
    const campo = document.getElementById(id);
    if (campo) campo.disabled = !habilitar;
  });

  // Corrigido: habilita/desabilita o botão com id "btn-carregar-foto"
  const btnFoto = document.getElementById('btn-carregar-foto');
  if (btnFoto) btnFoto.disabled = !habilitar;
}


function formatarDataLocal(data) {
  if (!data) return '';
  // Evita a conversão de fuso horário
  return typeof data === 'string' && data.length >= 10 ? data.substring(0, 10) : '';
}


function preencherCampos(d) {
  document.getElementById('nomeContato').value = d.nomeContato || '';
  document.getElementById('cpfContato').value = d.cpfContato || '';
  document.getElementById('email').value = d.email || '';
  document.getElementById('telefoneContato').value = d.telefoneContato || '';

  document.getElementById('nomeDesaparecido').value = d.nomeDesaparecido || '';
  document.getElementById('dataNascimento').value = formatarDataLocal(d.dataNascimento);
  document.getElementById('nomeMae').value = d.nomeMae || '';
  document.getElementById('dataDesaparecimento').value = formatarDataLocal(d.dataDesaparecimento);
  document.getElementById('localDesaparecimento').value = d.localDesaparecimento || '';
  document.getElementById('numeroBo').value = d.numeroBo || '';
  document.getElementById('outrasInformacoes').value = d.outrasInformacoes || '';

  const fotoEl = document.getElementById('fotoExibida');
  if (d.foto && d.foto.trim() !== '') {
    fotoEl.src = `/fotos/${d.foto}`;
    fotoEl.style.display = 'block';
  } else {
    fotoEl.src = '';
    fotoEl.style.display = 'none';
  }
}


function formatarDataISO(data) {
  if (!data) return '';
  return new Date(data).toISOString().split('T')[0];
}

async function salvarDados(customId) {
  const formData = new FormData(document.getElementById('form-desaparecido'));

  try {
    const resposta = await fetch(`/editar_desaparecido/${customId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        nomeContato: formData.get('nomeContato'),
        cpfContato: formData.get('cpfContato'),
        email: formData.get('email'),
        telefoneContato: formData.get('telefoneContato'),
        nomeDesaparecido: formData.get('nomeDesaparecido'),
        dataNascimento: formData.get('dataNascimento'),
        nomeMae: formData.get('nomeMae'),
        dataDesaparecimento: formData.get('dataDesaparecimento'),
        localDesaparecimento: formData.get('localDesaparecimento'),
        numeroBo: formData.get('numeroBo'),
        outrasInformacoes: formData.get('outrasInformacoes')
      })
    });

    if (resposta.ok) {
      alert('Dados salvos com sucesso!');
    } else {
      const data = await resposta.json();
      alert('Erro ao salvar: ' + (data.message || 'Erro desconhecido.'));
    }
  } catch (err) {
    console.error('Erro ao salvar:', err);
    alert('Erro ao salvar os dados.');
  }
}

async function carregarDados(customId) {
  try {
    const resposta = await fetch(`/buscar_desaparecido/${customId}`);
    const dados = await resposta.json();

    if (!dados) throw new Error('Dados não encontrados.');

    preencherCampos(dados);
    habilitarCampos(false);
  } catch (erro) {
    console.error('Erro ao carregar dados:', erro);
    alert('Erro ao carregar dados. Redirecionando...');
    window.location.href = 'desaparecidos_Lista.html';
  }
}