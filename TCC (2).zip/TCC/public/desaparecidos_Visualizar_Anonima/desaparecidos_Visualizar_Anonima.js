// desaparecidos_Visualizar_Anonima.js

// Ao carregar a página
document.addEventListener('DOMContentLoaded', async () => {
  validarSessao();

  const urlParams = new URLSearchParams(window.location.search);
  const customId = urlParams.get('id');

  if (!customId) {
    alert('ID inválido. Retornando à lista.');
    window.location.href = '../desaparecidos_Lista/desaparecidos_Lista.html';
    return;
  }

  await carregarDadosAnonima(customId);
});

// Apenas redireciona
function sair() {
  window.location.href = 'http://localhost:3000/desaparecidos_Lista_Anonima/desaparecidos_Lista_Anonima.html';
}

// Validação da sessão do admin
function validarSessao() {
  fetch('/verificar_sessao_admin')
    .then(res => res.json())
    .then(data => {
      if (!data.logado) {
        alert('Você precisa estar logado como administrador!');
        window.location.href = '../administrador_Login/administrador_Login.html';
      } else {
        document.getElementById('admin-nome').textContent = `Bem-vindo(a),  ${data.nome}`;
      }
    })
    .catch(err => {
      console.error('Erro ao verificar sessão:', err);
      alert('Erro ao verificar sessão. Redirecionando...');
      window.location.href = '../administrador_Login/administrador_Login.html';
    });
}

function formatarDataLocal(data) {
  if (!data) return '';
  return typeof data === 'string' && data.length >= 10 ? data.substring(0, 10) : '';
}

function preencherCamposAnonimo(d) {
  document.getElementById('cidade').value = d.cidade || '';

  document.getElementById('nomeDesaparecido').value = d.nomeDesaparecido || '';
  document.getElementById('dataNascimento').value = formatarDataLocal(d.dataNascimento);
  document.getElementById('nomeMae').value = d.nomeMae || '';
  document.getElementById('dataDesaparecimento').value = formatarDataLocal(d.dataDesaparecimento);
  document.getElementById('localDesaparecimento').value = d.localDesaparecimento || '';
  document.getElementById('numeroBo').value = d.numeroBo || '';
  document.getElementById('outrasInformacoes').value = d.outrasInformacoes || '';

  const fotoEl = document.getElementById('fotoExibida');
  if (d.foto && d.foto.trim() !== '') {
    fotoEl.src = `/fotos/${d.foto}`;
    fotoEl.style.display = 'block';
  } else {
    fotoEl.src = '';
    fotoEl.style.display = 'none';
  }
}

async function carregarDadosAnonima(customId) {
  try {
    const resposta = await fetch(`/buscar_desaparecido/${customId}`);
    const dados = await resposta.json();

    if (!dados || !dados.denunciaAnonima) {
      alert('Esta denúncia não é anônima ou não foi encontrada.');
      window.location.href = '../desaparecidos_Lista/desaparecidos_Lista.html';
      return;
    }

    preencherCamposAnonimo(dados);
  } catch (erro) {
    console.error('Erro ao carregar dados:', erro);
    alert('Erro ao carregar dados. Redirecionando...');
    window.location.href = '../desaparecidos_Lista_Anonima.html';
  }
}
