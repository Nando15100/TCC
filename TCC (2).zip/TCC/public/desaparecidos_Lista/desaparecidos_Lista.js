// Carrega os desaparecidos ao iniciar a página
async function carregarDesaparecidos() {
  try {
    const resposta = await fetch('/listar_desaparecidos');
    const dados = await resposta.json();

    const corpo = document.getElementById('corpo-tabela');
    corpo.innerHTML = '';

    if (dados.length === 0) {
      corpo.innerHTML = '<tr><td colspan="5">Nenhum desaparecido encontrado.</td></tr>';
      return;
    }

    dados.forEach(pessoa => {
      const tr = document.createElement('tr');

      const dataDesap = pessoa.dataDesaparecimento
  ? pessoa.dataDesaparecimento.substring(0, 10).split('-').reverse().join('/')
  : '';

      tr.innerHTML = `
        <td>${pessoa.customId}</td>
        <td>${pessoa.nomeDesaparecido || 'Sem nome'}</td>
        <td>${pessoa.nomeMae || 'Sem nome'}</td>
        <td>${dataDesap}</td>
        <td>
          <button onclick="editar(${pessoa.customId})" class="btn btn-warning btn-sm me-2">✏️</button>
          <button onclick="excluir(${pessoa.customId})" class="btn btn-danger btn-sm me-2">🗑️</button>
          <button onclick="visualizar(${pessoa.customId})" class="btn btn-info btn-sm">👁️</button>
        </td>
      `;

      corpo.appendChild(tr);
    });

  } catch (erro) {
    console.error('Erro ao carregar desaparecidos:', erro);
  }
}

window.onload = carregarDesaparecidos;

// Função para excluir desaparecido
async function excluir(customId) {
  if (!confirm('Tem certeza que deseja excluir este desaparecido?')) return;

  try {
    const resposta = await fetch(`/excluir_desaparecido/${customId}`, {
      method: 'DELETE'
    });

    if (resposta.ok) {
      alert('Registro excluído com sucesso!');
      carregarDesaparecidos();
    } else {
      alert('Erro ao excluir. Tente novamente.');
    }
  } catch (err) {
    console.error('Erro ao excluir:', err);
    alert('Erro ao excluir. Verifique o console.');
  }
}

// Função para abrir modal de edição
async function editar(customId) {
  try {
    const resposta = await fetch(`/buscar_desaparecido/${customId}`);
    if (!resposta.ok) throw new Error('Registro não encontrado');
    const dados = await resposta.json();

    document.getElementById('edit-id').value = customId;
    document.getElementById('edit-nome').value = dados.nomeDesaparecido || '';
    document.getElementById('edit-mae').value = dados.nomeMae || '';
    document.getElementById('edit-data').value = dados.dataDesaparecimento
      ? new Date(dados.dataDesaparecimento).toISOString().split('T')[0]
      : '';

    const modal = new bootstrap.Modal(document.getElementById('modalEdicao'));
    modal.show();

  } catch (erro) {
    console.error('Erro ao buscar desaparecido:', erro);
    alert('Erro ao carregar dados para edição.');
  }
}

// Submit do modal de edição
document.getElementById('form-edicao').addEventListener('submit', async function (e) {
  e.preventDefault();

  const customId = document.getElementById('edit-id').value;
  const nomeDesaparecido = document.getElementById('edit-nome').value.trim();
  const nomeMae = document.getElementById('edit-mae').value.trim();
  const dataDesaparecimento = document.getElementById('edit-data').value;

  try {
    const resposta = await fetch(`/editar_desaparecido/${customId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nomeDesaparecido, nomeMae, dataDesaparecimento })
    });

    if (resposta.ok) {
      alert('Registro atualizado com sucesso!');
      bootstrap.Modal.getInstance(document.getElementById('modalEdicao')).hide();
      carregarDesaparecidos();
    } else {
      alert('Erro ao atualizar registro.');
    }
  } catch (erro) {
    console.error('Erro ao atualizar:', erro);
    alert('Erro ao atualizar desaparecido.');
  }
});

// Função para visualizar desaparecido (redireciona para página de visualização)
function visualizar(customId) {
  // Você pode passar o id via query string para a página visualizar
  window.location.href = `/desaparecidos_Visualizar/desaparecidos_Visualizar.html?id=${customId}`;

}

function pesquisando_Dados() {
    const filtro = document.getElementById('pesquisar').value.toLowerCase();
    const linhas = document.querySelectorAll('#corpo-tabela tr');

    // Remove a linha da mensagem, se estiver presente
    const linhaMensagem = document.getElementById('linha-vazia');
    if (linhaMensagem) linhaMensagem.remove();

    let encontrou = false;

    linhas.forEach(tr => {
        const id = tr.cells[0].textContent.toLowerCase();      // Coluna ID
        const nome = tr.cells[1].textContent.toLowerCase();    // Coluna Nome

                            /*Pesquisa por ID*/    /*PESQUISA POR NOME*/
        const corresponde = id.includes(filtro) || nome.includes(filtro);

        tr.style.display = corresponde ? '' : 'none';
        if (corresponde) encontrou = true;
    });

    if (!encontrou) {
        const tbody = document.getElementById('corpo-tabela');
        const tr = document.createElement('tr');
        tr.id = 'linha-vazia';
        tr.classList.add('mensagem-vazia');
        tr.innerHTML = `<td colspan="6">Nenhum registro encontrado.</td>`;
        tbody.appendChild(tr);
    }
}
document.getElementById('pesquisar')
    .addEventListener('keydown', e => {
        if (e.key === 'Enter') {
            e.preventDefault();
            pesquisando_Dados();
        }
    });
