const botao_Enviar = document.getElementById('form-cadastro');

botao_Enviar.addEventListener('submit', cadastrar_Usuario);

async function cadastrar_Usuario(evento) {
  evento.preventDefault();

  const nome = document.getElementById('usuario').value.trim();
  const cpf = document.getElementById('cpf').value;
  const confirmaCpf = document.getElementById('confirmaCpf').value;

  if (cpf.length < 11) {
    return alert("O CPF deve ter 11 números.");
  }

  if (cpf !== confirmaCpf) {
    return alert("CPF e confirmação de CPF não coincidem.");
  }

  try {
    const resposta = await fetch('/usuario_cadastro', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nome, cpf })
    });

    const json = await resposta.json();
    alert(json.message); // <-- aqui, mostra a mensagem de texto correta


    if (resposta.ok) {
      window.location.href = '/usuario_Login/usuario_Login.html';
    }

  } catch (erro) {
    console.error('Erro ao cadastrar:', erro);
    alert('Erro ao cadastrar. Tente novamente mais tarde.');
  }
}
