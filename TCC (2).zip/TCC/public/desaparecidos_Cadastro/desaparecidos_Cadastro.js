// Verifica se a sessão do usuário está ativa
fetch('/usuario_sessao')
  .then(res => {
    if (!res.ok) {
      throw new Error('Sessão não encontrada');
    }
    return res.json();
  })
  .then(data => {
    const nomeSpan = document.getElementById('usuario-nome'); // <- aqui estava o erro
    if (nomeSpan) {
      nomeSpan.textContent = `Bem-vindo(a) ${data.nome}`;
    }
  })
  .catch(err => {
    console.error('Erro ao verificar sessão:', err);
    alert('Você precisa estar logado como usuário!');
    window.location.href = '../usuario_Login/usuario_Login.html';
  });



 

  // Manipula o envio do formulário de cadastro
  const form = document.getElementById('form-desaparecido');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const outrasInfo = document.getElementById('outrasInformacoes').value.trim();
    if (outrasInfo === '') {
      alert('Campo "Outras Informações" é obrigatório o preenchimento.');
      return;
    }

    const formData = new FormData(form);

    // Atualiza o campo cidade somente se estiver habilitado (denúncia anônima)
    const cidadeInput = document.getElementById('cidade');
    if (!cidadeInput.disabled) {
      formData.set('cidade', cidadeInput.value.trim());
    } else {
      formData.delete('cidade');
    }

    // Atualiza o campo denunciaAnonima manualmente no FormData
    const isAnonimo = document.getElementById('anonimoCheckbox').checked;
    formData.set('denunciaAnonima', isAnonimo ? 'true' : 'false');

    try {
      const response = await fetch('/desaparecidos_Cadastro', {
        method: 'POST',
        body: formData
      });

      if (response.ok) {
        alert('Cadastro realizado com sucesso!');
        form.reset();
        document.getElementById('cidade').disabled = true;
        document.getElementById('denunciaAnonima').value = 'false';
      } else {
        const data = await response.json();
        alert('Erro: ' + (data.message || 'Não foi possível cadastrar.'));
      }
    } catch (error) {
      alert('Erro na conexão com o servidor.');
      console.error('Erro:', error);
    }
  });

