""// server.js atualizado com suporte à lista anônima de desaparecidos

const express = require('express');
const session = require('express-session');
const mongoose = require('mongoose');
const multer = require('multer');
const path = require('path');

const Administrador = require('./models/Administrador');
const Usuario = require('./models/Usuario');
const Desaparecido = require('./models/Desaparecido');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use(session({
  secret: 'chaveSecretaDoAdministrador',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false }
}));

mongoose.connect('mongodb://localhost:27017/Tcc')
  .then(() => console.log('MongoDB conectado!'))
  .catch(err => console.error('Erro na conexão:', err));

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});

// ---------------- ADMINISTRADOR ----------------

async function gerarCustomId() {
  const ultima = await Administrador.findOne().sort({ customId: -1 });
  return ultima ? ultima.customId + 1 : 1;
}

app.post('/salvar_Administrador', async (req, res) => {
  try {
    const { nome, senha, celular } = req.body;
    const existente = await Administrador.findOne({ nome });
    if (existente) return res.status(409).json({ message: 'Este nome de administrador já está em uso.' });

    const customId = await gerarCustomId();
    const administrador = new Administrador({ customId, nome, senha, celular });
    await administrador.save();

    res.status(201).json({ message: 'Dados salvos com sucesso!' });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao salvar dados' });
  }
});

app.get('/registros_Administrador', async (req, res) => {
  try {
    const registros = await Administrador.find();
    res.json(registros);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao buscar registros' });
  }
});

app.put('/atualizar_Administrador/:id', async (req, res) => {
  const id = parseInt(req.params.id);
  const { nome, senha, celular } = req.body;
  try {
    await Administrador.updateOne({ customId: id }, { $set: { nome, senha, celular } });
    res.sendStatus(200);
  } catch (err) {
    res.status(500).send('Erro ao atualizar registro');
  }
});

app.delete('/excluir_Administrador/:customId', async (req, res) => {
  await Administrador.findOneAndDelete({ customId: req.params.customId });
  res.json({ message: 'Registro excluído!' });
});

app.post('/Administrador_Login', async (req, res) => {
  const { usuario, senha } = req.body;
  try {
    const administrador = await Administrador.findOne({ nome: usuario });
    if (!administrador || administrador.senha !== senha) {
      return res.status(401).json({ message: 'Usuário ou senha inválidos!' });
    }
    req.session.adminId = administrador.customId;
    req.session.adminNome = administrador.nome;
    res.status(200).json({ autenticado: true });
  } catch (error) {
    res.status(500).json({ message: 'Erro interno no servidor' });
  }
});

app.get('/verificar_sessao_admin', (req, res) => {
  if (req.session.adminId) {
    res.status(200).json({ logado: true, nome: req.session.adminNome });
  } else {
    res.status(401).json({ logado: false });
  }
});

app.get('/logout_Administrador', (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).send('Erro ao encerrar a sessão');
    res.redirect('/administrador_Login/administrador_Login.html');
  });
});

// ---------------- USUÁRIO ----------------

app.post('/usuario_cadastro', async (req, res) => {
  try {
    const { nome, cpf } = req.body;
    const existente = await Usuario.findOne({ nome });
    if (existente) return res.status(409).json({ message: 'Este nome de usuario já está em uso.' });

    const ultimo = await Usuario.findOne().sort({ customId: -1 });
    const customId = ultimo ? ultimo.customId + 1 : 1;
    const usuario = new Usuario({ customId, nome, cpf });
    await usuario.save();

    res.status(201).json({ message: 'Dados salvos com sucesso!' });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao salvar dados' });
  }
});

app.get('/registros_Usuario', async (req, res) => {
  try {
    const registros = await Usuario.find();
    res.json(registros);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao buscar registros' });
  }
});

app.put('/atualizar_Usuario/:id', async (req, res) => {
  const id = parseInt(req.params.id);
  const { nome, cpf } = req.body;
  try {
    await Usuario.updateOne({ customId: id }, { $set: { nome, cpf } });
    res.sendStatus(200);
  } catch (err) {
    res.status(500).send('Erro ao atualizar registro');
  }
});

app.delete('/excluir_Usuario/:customId', async (req, res) => {
  await Usuario.findOneAndDelete({ customId: req.params.customId });
  res.json({ message: 'Registro excluído!' });
});




app.post('/usuario_login', async (req, res) => {
  const { nome, cpf } = req.body;

  try {
    const usuario = await Usuario.findOne({ nome, cpf });

    if (!usuario) {
      return res.status(401).json({ mensagem: 'Usuário ou CPF incorretos.' });
    }

    // Salve o id do usuário também na sessão
    req.session.usuario = { nome: usuario.nome, _id: usuario._id };

    res.status(200).json({ mensagem: 'Login bem-sucedido!' });
  } catch (erro) {
    console.error('Erro no login:', erro);
    res.status(500).json({ mensagem: 'Erro no servidor' });
  }
});



app.get('/usuario_sessao', (req, res) => {
  if (req.session.usuario) {
    res.json({ nome: req.session.usuario.nome });
  } else {
    res.status(401).json({ mensagem: 'Não logado.' });
  }
});


app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/usuario_Login/usuario_Login.html');
  });
});



// ---------------- DESAPARECIDO ----------------

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, 'public', 'fotos')),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});

const upload = multer({ storage });

async function gerarIdDesaparecido() {
  const ultimo = await Desaparecido.findOne().sort({ customId: -1 });
  return ultimo ? ultimo.customId + 1 : 1;
}

app.post('/desaparecidos_Cadastro', upload.single('foto'), async (req, res) => {
  try {
    const usuario = req.session.usuario;
    if (!usuario) {
      return res.status(401).json({ mensagem: 'Usuário não logado' });
    }

    const customId = await gerarIdDesaparecido();

    const novoDesaparecido = new Desaparecido({
      customId,
      nomeContato: req.body.nomeContato || '',
      cpfContato: req.body.cpfContato || '',
      cidade: req.body.cidade || '',
      email: req.body.email || '',
      telefoneContato: req.body.telefoneContato || '',
      nomeDesaparecido: req.body.nomeDesaparecido,
      dataNascimento: req.body.dataNascimento,
      nomeMae: req.body.nomeMae,
      dataDesaparecimento: req.body.dataDesaparecimento,
      localDesaparecimento: req.body.localDesaparecimento,
      numeroBo: req.body.numeroBo,
      outrasInformacoes: req.body.outrasInformacoes,
      foto: req.file ? req.file.filename : '',
      denunciaAnonima: req.body.denunciaAnonima === 'true',
      criadoPor: usuario._id  // <-- Aqui é onde vinculamos o usuário da sessão
    });

    await novoDesaparecido.save();

    res.status(201).json({ message: 'Cadastro realizado com sucesso!' });
  } catch (err) {
    console.error('Erro no cadastro de desaparecido:', err);
    res.status(500).json({ message: 'Erro ao cadastrar desaparecido' });
  }
});

app.get('/listar_desaparecidos', async (req, res) => {
  const usuarioId = req.session.usuario?._id;

  if (!usuarioId) {
    return res.status(401).json({ erro: 'Usuário não logado' });
  }

  try {
    const desaparecidos = await Desaparecido.find(
      { criadoPor: usuarioId }, // pega todos os registros feitos por ele (anônimos ou não)
      {
        customId: 1,
        nomeDesaparecido: 1,
        nomeMae: 1,
        dataDesaparecimento: 1,
        denunciaAnonima: 1,
        cidade: 1
      }
    ).sort({ customId: 1 });

    res.json(desaparecidos);
  } catch (error) {
    console.error('Erro ao buscar desaparecidos:', error);
    res.status(500).json({ erro: 'Erro ao buscar desaparecidos' });
  }
});








// Rota para listar desaparecidos anônimos
app.get('/listar_desaparecidos_anonimos', async (req, res) => {
  try {
    const desaparecidosAnonimos = await Desaparecido.find(
      { denunciaAnonima: true },
      {
        customId: 1,
        cidade: 1
      }
    ).sort({ customId: 1 });

    res.json(desaparecidosAnonimos);
  } catch (error) {
    console.error('Erro ao buscar desaparecidos anônimos:', error);
    res.status(500).json({ erro: 'Erro ao buscar desaparecidos anônimos' });
  }
});
// NOVA ROTA: editar apenas a cidade de um desaparecido anônimo
// Rota para editar cidade (atenção ao nome da rota: /editar_cidade/:customId)
app.put('/editar_cidade/:customId', async (req, res) => {
  const id = parseInt(req.params.customId);
  const { cidade } = req.body;
  try {
    const atualizado = await Desaparecido.updateOne(
      { customId: id },
      { $set: { cidade } }
    );
    if (atualizado.matchedCount === 0) {
      return res.status(404).json({ message: 'Registro não encontrado para atualizar' });
    }
    res.status(200).json({ message: 'Cidade atualizada com sucesso!' });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao atualizar cidade.' });
  }
});



app.get('/buscar_desaparecido/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const pessoa = await Desaparecido.findOne({ customId: id });
    if (!pessoa) return res.status(404).json({ message: 'Desaparecido não encontrado.' });
    res.json(pessoa);
  } catch (err) {
    res.status(500).json({ message: 'Erro ao buscar desaparecido.' });
  }
});

app.delete('/excluir_desaparecido/:customId', async (req, res) => {
  try {
    await Desaparecido.findOneAndDelete({ customId: req.params.customId });
    res.json({ message: 'Desaparecido excluído com sucesso!' });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao excluir desaparecido.' });
  }
});

const fs = require('fs');

// PUT - Atualizar desaparecido com ou sem nova foto
app.put('/editar_desaparecido/:id', upload.single('foto'), async (req, res) => {
  const id = parseInt(req.params.id);
  const dados = req.body;

  try {
    // Se houver nova foto, atualizar o campo 'foto'
    if (req.file) {
      dados.foto = req.file.filename;
    }

    // Se não houver nova foto, manter a existente
    if (!req.file && dados.foto === '') {
      delete dados.foto; // não atualiza o campo
    }

    const atualizado = await Desaparecido.updateOne(
      { customId: id },
      { $set: dados }
    );

    if (atualizado.matchedCount === 0) {
      return res.status(404).json({ message: 'Desaparecido não encontrado para atualizar' });
    }

    res.status(200).json({ message: 'Dados atualizados com sucesso!' });

  } catch (error) {
    console.error('Erro ao atualizar desaparecido:', error);
    res.status(500).json({ message: 'Erro interno ao atualizar desaparecido.' });
  }
});


app.get('/desaparecido_detalhes/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const desaparecido = await Desaparecido.findOne({ customId: id });
    if (!desaparecido) return res.status(404).json({ message: 'Desaparecido não encontrado' });
    res.json(desaparecido);
  } catch (error) {
    res.status(500).json({ message: 'Erro interno no servidor' });
  }
});


app.put('/editar_desaparecido_rapido/:id', async (req, res) => {
  const id = parseInt(req.params.id);
  const { nomeDesaparecido, nomeMae, dataDesaparecimento } = req.body;

  try {
    const atualizado = await Desaparecido.updateOne(
      { customId: id },
      { $set: { nomeDesaparecido, nomeMae, dataDesaparecimento } }
    );

    if (atualizado.matchedCount === 0) {
      return res.status(404).json({ message: 'Desaparecido não encontrado para atualizar' });
    }

    res.status(200).json({ message: 'Dados atualizados com sucesso!' });
  } catch (error) {
    console.error('Erro ao atualizar desaparecido (edição rápida):', error);
    res.status(500).json({ message: 'Erro interno ao atualizar desaparecido.' });
  }
});



